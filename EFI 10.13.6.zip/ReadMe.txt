MacOS 10.13.6 EFI

P770dm-g laptop
CPU: i5 6600k or i9 9900k
Graphic Card: GTX 980m
Mother board: Z170
